"""
Declares the module.
"""
